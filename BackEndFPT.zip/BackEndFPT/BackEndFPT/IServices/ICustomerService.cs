﻿using BackEndFPT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BackEndFPT.IServices
{
    public interface ICustomerService
    {
        Customer Save(Customer customer);

        Customer Get(int IdCustomer);
        List<Customer> Gets();
        String Delete(int IdCustomer);
    }
}
