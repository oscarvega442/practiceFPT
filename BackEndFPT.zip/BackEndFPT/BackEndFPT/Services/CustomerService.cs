﻿using BackEndFPT.Common;
using BackEndFPT.IServices;
using BackEndFPT.Models;
using Dapper;
using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BackEndFPT.Services
{
    public class CustomerService : ICustomerService
    {
        Customer _customer = new Customer();
        List<Customer> _customers = new List<Customer>();

        public string Delete(int IdCustomer)
        {
            string message = "";

            try
            {

                using (IDbConnection con = new SqlConnection(Global.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed) con.Open();

                    var customers = con.Query<Customer>("Delete from Custumer where idCustomer= " + IdCustomer).ToList();

                    if (customers != null && customers.Count() > 0)
                    {
                        _customer = customers.FirstOrDefault();
                    }
                }
            }
            catch (Exception ex) 
            {
                message = ex.Message;
            }

            return message;
        }

        public Customer Get(int IdCustomer)
        {
            _customer = new Customer();

            using (IDbConnection con = new SqlConnection(Global.ConnectionString))
            {
                if (con.State == ConnectionState.Closed) con.Open();

                var customers = con.Query<Customer>("Select * from Custumer Where idCustomer =" + IdCustomer).ToList();

                if (customers != null && customers.Count() > 0)
                {
                    _customer = customers.SingleOrDefault();
                }
            }
            return _customer;

        }

        public List<Customer> Gets()
        {
            _customers = new List<Customer>();

            using (IDbConnection con = new SqlConnection(Global.ConnectionString))
            {
                if (con.State == ConnectionState.Closed) con.Open();

                var customers = con.Query<Customer>("Select * from Custumer").ToList();

                if (customers != null && customers.Count() > 0)
                {
                    _customers = customers;
                }
            }
            return _customers;

        }


        public Customer Save(Customer customer)
        {
            _customer = new Customer();

            try
            {
                int operationType = Convert.ToInt32(customer.idCustomer == 0 ? OperationType.Insert : OperationType.Update);

                using (IDbConnection con = new SqlConnection(Global.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed) con.Open();

                    var customers = con.Query<Customer>("Insert into Custumer (name, phone,email,notes) values()", this.SetParameters(customer, operationType), commandType: CommandType.Text);

                    if (customers != null && customers.Count() > 0)
                    {
                        _customer = customers.FirstOrDefault();
                    }
                }

            }
            catch (Exception ex)
            {
                _customer.name = ex.Message;
            }
            return _customer;
        }

        private DynamicParameters SetParameters(Customer customer, int operationType)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@idCustomer", customer.idCustomer);
            parameters.Add("@name", customer.name);
            parameters.Add("@phone", customer.phone);
            parameters.Add("@email", customer.email);
            parameters.Add("@notes", customer.notes);
            //parameters.Add("@operationType", operationType);

            return parameters;
        }
    }
}
