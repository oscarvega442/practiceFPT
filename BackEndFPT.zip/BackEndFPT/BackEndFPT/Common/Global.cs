﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BackEndFPT.Common
{
    public class Global
    {
        public static string ConnectionString { get; set; }
    }
}
