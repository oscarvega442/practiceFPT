﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BackEndFPT.Models
{
    public class Customer
    {
        public int idCustomer { get; set; }
        public string name { get; set; }
        public string phone { get; set; }
        public int email { get; set; }
        public int notes { get; set; }
    }
}
